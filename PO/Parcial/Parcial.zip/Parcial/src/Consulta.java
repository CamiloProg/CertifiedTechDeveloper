public class Consulta {
    private String fechaConsulta;
    private String especialidad;
    private String horaMinuto;

    public Consulta(String fechaConsulta, String especialidad, String horaMinuto) {
        this.fechaConsulta = fechaConsulta;
        this.especialidad = especialidad;
        this.horaMinuto = horaMinuto;
    }
}
